﻿/// ---------------------------------------------
/// Challenge System for Ultimate Character Controllers
/// Copyright (c) Birched Studios. All Rights Reserved.
/// https://birchedgamestudios.com
/// ---------------------------------------------

namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
    using Opsive.Shared.Editor.Inspectors.StateSystem;
	using Opsive.Shared.Editor.UIElements;
	using Opsive.Shared.StateSystem;
	using System.Collections.Generic;
	using UnityEditor;
	using UnityEngine;
	using UnityEngine.UIElements;
	using UnityEditor.UIElements;
	using ReorderableList = UnityEditorInternal.ReorderableList;

    [CustomEditor(typeof(AnimatedStateInteractable))]
    public class AnimatedStateInteractableInspector : UIElementsInspector
    {
        private const string c_EditorPrefsSelectedIndexKey =
            "Opsive.Shared.Editor.Inspectors.SelectedStateIndex";

        private const string c_StatesFoldoutKey =
            "Opsive.Shared.Editor.Inspectors.AnimatedInteractable.StatesFoldout";

		private const string c_SettingsFoldoutKey =
			"Opsive.Shared.Editor.Inspectors.AnimatedInteractable.SettingsFoldout";

        private const string c_CommandFoldoutKey =
            "Opsive.Shared.Editor.Inspectors.AnimatedInteractable.CommandsFoldout";

        private const string c_NoneCommand = "(none)";

        private string SelectedIndexKey =>
            c_EditorPrefsSelectedIndexKey + "." + target.GetType() + "." + target.name;

        private ReorderableList m_StateList;

        private SerializedProperty m_DefaultCommandProp;
		private SerializedProperty m_OneShotCommandsProp;
        private SerializedProperty m_DefaultMessageProp;
        private SerializedProperty m_FloatBlendProp;
        private SerializedProperty m_TargetValueProp;
        private SerializedProperty m_UseCharacterImpactProp;
        private SerializedProperty m_IntModeProp;
        private SerializedProperty m_BoolModeProp;
        private SerializedProperty m_FloatModeProp;

		private PropertyField m_OneShotCommandsField;
        private PropertyField m_DefaultMessageField;
        private PropertyField m_FloatBlendField;
        private PropertyField m_TargetValueField;
        private PropertyField m_UseCharacterImpactField;
        private PropertyField m_BoolModeField;
        private PropertyField m_FloatModeField;
        private PropertyField m_IntModeField;

        private VisualElement m_ModeDetailsContainer;
        private AnimatedStateInteractable m_AnimatedInteractable;

        private void OnEnable()
        {
            m_AnimatedInteractable = target as AnimatedStateInteractable;

            m_DefaultCommandProp = serializedObject.FindProperty("m_DefaultCommand");
			m_OneShotCommandsProp = serializedObject.FindProperty("m_OneShotCommands");
            m_DefaultMessageProp = serializedObject.FindProperty("m_DefaultMessage");
            m_FloatBlendProp = serializedObject.FindProperty("m_FloatBlendDuration");
            m_TargetValueProp = serializedObject.FindProperty("m_TargetValue");
            m_UseCharacterImpactProp = serializedObject.FindProperty("m_UseCharacterImpact");
            m_BoolModeProp = serializedObject.FindProperty("m_BoolMode");
            m_FloatModeProp = serializedObject.FindProperty("m_FloatMode");
            m_IntModeProp = serializedObject.FindProperty("m_IntMode");
        }

        public override VisualElement CreateInspectorGUI()
        {
            var root = base.CreateInspectorGUI();

            PropertyField scriptField = null;
            root.Query<PropertyField>().ForEach(field => {
                if (field.bindingPath == "m_Script" && scriptField == null) {
                    scriptField = field;
                }
            });

            var header = new VisualElement();

            m_ModeDetailsContainer = new VisualElement();
            m_ModeDetailsContainer.style.marginLeft = 15f;
            header.Add(m_ModeDetailsContainer);

            m_ModeDetailsContainer.Add(BuildCommandFoldout());

            m_DefaultMessageField = new PropertyField(m_DefaultMessageProp, "Default Message");
            m_BoolModeField = new PropertyField(m_BoolModeProp, "Bool Type");
            m_FloatModeField = new PropertyField(m_FloatModeProp, "Float Type");
            m_FloatBlendField = new PropertyField(m_FloatBlendProp, "Float Blend Speed");
            m_IntModeField = new PropertyField(m_IntModeProp, "Int Type");
            m_TargetValueField = new PropertyField(m_TargetValueProp, "Target Value");
            m_UseCharacterImpactField = new PropertyField(m_UseCharacterImpactProp, "Character Impact");
			m_OneShotCommandsField = new PropertyField(m_OneShotCommandsProp, "One-Shot Commands");

			m_ModeDetailsContainer.Add(BuildSettingsFoldout());

            if (scriptField != null) {
                var parent = scriptField.parent ?? root;
                var index = parent.IndexOf(scriptField);
                parent.Insert(index + 1, header);
            } else {
                root.Insert(0, header);
            }

            var stateContainer = new IMGUIContainer(DrawStatesIMGUI) {
                style = {
                    marginLeft = -12,
                    marginTop = 0
                }
            };
            root.Add(stateContainer);

            return root;
        }

        private VisualElement BuildCommandFoldout()
        {
            var foldout = new Foldout {
                text = "Animator Commands",
                value = EditorPrefs.GetBool(c_CommandFoldoutKey, true)
            };

            foldout.RegisterValueChangedCallback(evt => {
                EditorPrefs.SetBool(c_CommandFoldoutKey, evt.newValue);
            });

            var commandNames = GetAnimatorParameterNames();
            var choices = new List<string> { c_NoneCommand };
            choices.AddRange(commandNames);

            serializedObject.Update();

            var current = string.IsNullOrEmpty(m_DefaultCommandProp.stringValue)
                ? c_NoneCommand
                : m_DefaultCommandProp.stringValue;

            if (!choices.Contains(current)) {
                choices.Add(current);
            }

            var popup = new PopupField<string>("Default Command", choices, current);
            popup.tooltip =
                "Default command executed when Interact is called without a specific command.\n" +
                "If set, this can be used as an override to force a specific interaction behavior.";

            popup.RegisterValueChangedCallback(evt => {
                serializedObject.Update();
                m_DefaultCommandProp.stringValue = evt.newValue == c_NoneCommand ? string.Empty : evt.newValue;
                serializedObject.ApplyModifiedProperties();
                Shared.Editor.Utility.EditorUtility.RecordUndoDirtyObject(target, "Change Default Command");
            });

            foldout.Add(popup);

            if (commandNames.Count == 0) {
                var help = new HelpBox(
                    "No Animator parameters were found. Add parameters to the Animator to expose command options.",
                    HelpBoxMessageType.Info
                );
                foldout.Add(help);
                return foldout;
            }

            for (int i = 0; i < commandNames.Count; i++) {
                var field = new TextField($"Command {i + 1}") {
                    value = commandNames[i],
                    isReadOnly = true
                };

                field.SetEnabled(false);
                foldout.Add(field);
            }

            return foldout;
        }

		private VisualElement BuildSettingsFoldout()
		{
			var foldout = new Foldout {
				text = "Command Settings",
				value = EditorPrefs.GetBool(c_SettingsFoldoutKey, true)
			};

			foldout.RegisterValueChangedCallback(evt => {
				EditorPrefs.SetBool(c_SettingsFoldoutKey, evt.newValue);
			});

			foldout.Add(m_DefaultMessageField);
			foldout.Add(m_BoolModeField);
			foldout.Add(m_FloatModeField);
			foldout.Add(m_FloatBlendField);
			foldout.Add(m_IntModeField);
			foldout.Add(m_TargetValueField);
			foldout.Add(m_UseCharacterImpactField);
			foldout.Add(m_OneShotCommandsField);

			return foldout;
		}

        private List<string> GetAnimatorParameterNames()
        {
            var names = new List<string>();

            if (m_AnimatedInteractable == null) {
                return names;
            }

            var animator = m_AnimatedInteractable.GetComponent<Animator>();
            if (animator == null || animator.parameters == null) {
                return names;
            }

            for (int i = 0; i < animator.parameters.Length; i++) {
                var parameter = animator.parameters[i];
                if (string.IsNullOrEmpty(parameter.name)) {
                    continue;
                }

                if (!names.Contains(parameter.name)) {
                    names.Add(parameter.name);
                }
            }

            return names;
        }

        private void DrawStatesIMGUI()
        {
            if (!(target is IStateOwner stateOwner)) {
                return;
            }

            serializedObject.Update();
            EditorGUI.BeginChangeCheck();

            var expanded = EditorPrefs.GetBool(c_StatesFoldoutKey, true);
            expanded = EditorGUILayout.Foldout(expanded, " States", true);
            EditorPrefs.SetBool(c_StatesFoldoutKey, expanded);

            if (expanded) {
                var statesProperty = serializedObject.FindProperty("m_States");
                m_StateList = StateInspector.DrawStates(
                    m_StateList,
                    serializedObject,
                    statesProperty,
                    SelectedIndexKey,
                    OnStateListDraw,
                    OnStateListAdd,
                    OnStateListReorder,
                    OnStateListRemove
                );
            }

            if (EditorGUI.EndChangeCheck()) {
                Shared.Editor.Utility.EditorUtility.RecordUndoDirtyObject(target, "Change Value");
                serializedObject.ApplyModifiedProperties();
                StateInspector.UpdateDefaultStateValues(stateOwner.States);
            }
        }

        private void OnStateListDraw(Rect rect, int index, bool isActive, bool isFocused)
        {
            StateInspector.OnStateListDraw(
                target,
                (target as IStateOwner).States,
                serializedObject.FindProperty("m_States"),
                rect,
                index
            );
        }

        private void OnStateListAdd(ReorderableList list)
        {
            StateInspector.OnStateListAdd(AddExistingPreset, CreatePreset);
        }

        private void AddExistingPreset()
        {
            var stateOwner = target as IStateOwner;
            stateOwner.States = StateInspector.AddExistingPreset(
                stateOwner.GetType(),
                stateOwner.States,
                m_StateList,
                SelectedIndexKey
            );
        }

        private void CreatePreset()
        {
            var stateOwner = target as IStateOwner;
            stateOwner.States = StateInspector.CreatePreset(
                target,
                stateOwner.States,
                m_StateList,
                SelectedIndexKey
            );
        }

        private void OnStateListReorder(ReorderableList list)
        {
            var stateOwner = target as IStateOwner;
            stateOwner.States = StateInspector.OnStateListReorder(stateOwner.States);
            EditorPrefs.SetInt(SelectedIndexKey, list.index);
        }

        private void OnStateListRemove(ReorderableList list)
        {
            var stateOwner = target as IStateOwner;
            stateOwner.States = StateInspector.OnStateListRemove(
                stateOwner.States,
                serializedObject.FindProperty("m_States"),
                SelectedIndexKey,
                list
            );
        }
    }
}