﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
    using Opsive.UltimateCharacterController.AddOns.Challenge.Interactive;
    using Opsive.UltimateCharacterController.AddOns.Challenge.Interactive.Elements;
    using UnityEngine;

    /// <summary>
    /// A simple lockpick-style rotation puzzle.
    /// Each interactive element has a target orientation defined by its original local Z rotation.
    /// The challenge begins by randomizing those rotations, and succeeds when all
    /// tracked elements are returned within the allowed angular margin.
    /// </summary>
    public class Lockpick : InteractiveGameplayBase
    {
		[Tooltip("The Amount in degrees that elements can deviate from solve position in order to pass.")]
        [SerializeField, Min(0f)] private float m_SolveMargin = 5f;
		[Tooltip("The degree of rotation used to randomly scramble element rotations.")]
        [SerializeField, Min(0.001f)] private float m_RotationStep = 45f;

        private RectTransform[] m_Rects;
        private float[] m_TargetZ;
        private bool m_Cached;

		public bool IsCached => m_Cached;
        public bool IsSolved() { return AllAligned(); }
		public float RotationStep => m_RotationStep;

        protected override void InitializeInternal() {
            base.InitializeInternal();
            CacheRects();
        }

        protected override void StartChallengeInternal(in Challenge challenge) {
            base.StartChallengeInternal(in challenge);
            Scramble();
        }

        protected override bool ResetInternal() {
            Scramble();
            return true;
        }

        protected override bool SubmitInternal() {
			return AllAligned();
		}

        protected override bool CanAutoSubmit() {
			return base.CanAutoSubmit() && AllAligned();
		}

        private void CacheRects() {
            if (m_Cached) { return; }

            var elements = InteractiveElements;
            if (elements == null || elements.Length == 0) { return; }

            m_Rects = new RectTransform[elements.Length];
            m_TargetZ = new float[elements.Length];

            for (int i = 0; i < elements.Length; i++) {
                var rect = elements[i] != null ? elements[i].transform as RectTransform : null;
                m_Rects[i] = rect;
                m_TargetZ[i] = rect != null ? Mathf.Repeat(rect.localEulerAngles.z, 360f) : 0f;
            }

            m_Cached = true;
        }

        private void Scramble() {
            if (m_Rects == null || m_TargetZ == null) { return; }

            var stepCount = Mathf.Max(1, Mathf.RoundToInt(360f / Mathf.Max(0.001f, m_RotationStep)));
            if (stepCount <= 1) { return; }

            var step = 360f / stepCount;

            for (int i = 0; i < m_Rects.Length; i++) {
                var rect = m_Rects[i];
                if (rect == null) { continue; }

                var solvedStep = Mathf.RoundToInt(m_TargetZ[i] / step) % stepCount;
                var randomStep = Random.Range(0, stepCount - 1);
                if (randomStep >= solvedStep) { randomStep++; }

                var z = Mathf.Repeat(randomStep * step, 360f);
                var animated = rect.GetComponent<AnimatedElement>();

                if (animated != null) {
                    animated.SnapRotation(z);
                } else {
                    var angles = rect.localEulerAngles;
                    angles.z = z;
                    rect.localEulerAngles = angles;
                }
            }
        }

        private bool AllAligned() {
            if (m_Rects == null || m_TargetZ == null || m_Rects.Length == 0) { return false; }

            for (int i = 0; i < m_Rects.Length; i++) {
                var rect = m_Rects[i];
                if (rect == null || Mathf.Abs(Mathf.DeltaAngle(rect.localEulerAngles.z, m_TargetZ[i])) > m_SolveMargin) {
                    return false;
                }
            }

            return true;
        }
    }
}