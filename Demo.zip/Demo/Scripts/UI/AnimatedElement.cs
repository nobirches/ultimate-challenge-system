﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
    using System.Collections.Generic;
    using UnityEngine;

    /// <summary>
    /// Lightweight RectTransform motion executor that aggregates active movement effects each frame.
    /// Effects contribute positional, rotational, and scale offsets which are blended together
    /// against a cached resting state and optionally committed on completion.
    /// </summary>
    [DisallowMultipleComponent]
    public class AnimatedElement : MonoBehaviour
    {
        protected enum EffectChannel
        {
            Position,
            Rotation,
            Scale
        }

        protected struct MotionEffect
        {
            public EffectChannel Channel;
            public Vector2[] Points;
            public float DurationPerPoint;
            public float Elapsed;
            public bool CommitOnComplete;
        }

        [Header("References")]
        [Tooltip("The RectTransform to drive. Defaults to this transform.")]
        [SerializeField] protected RectTransform m_RectTransform;
        [Tooltip("Optional canvas used to clamp anchored position.")]
        [SerializeField] protected Canvas m_Canvas;

        [Header("Defaults")]
        [Tooltip("Default seconds per point.")]
        [SerializeField] protected float m_DefaultDurationPerPoint = 0.04f;
        [Tooltip("Clamp anchored position inside the acting canvas.")]
        [SerializeField] protected bool m_ClampToCanvas = true;

        [Header("Circular Position Clamp")]
        [Tooltip("When enabled, summed position offsets are constrained radially so diagonal motion is not faster than straight motion.")]
        [SerializeField] protected bool m_UseCircularPositionClamp = true;

        [Header("Active Effect Limits")]
        [Tooltip("Maximum simultaneously active position effects.")]
        [SerializeField] protected int m_MaxPositionEffects = 12;
        [Tooltip("Maximum simultaneously active rotation effects.")]
        [SerializeField] protected int m_MaxRotationEffects = 6;
        [Tooltip("Maximum simultaneously active scale effects.")]
        [SerializeField] protected int m_MaxScaleEffects = 6;

		[Header("Translate")]
		[SerializeField] protected float m_TranslateMultiplier = 1f;

		[Header("Rotate")]
		[SerializeField] protected float m_RotationMultiplier = 1f;

        [Header("Shake")]
        [Tooltip("Default shake magnitude in anchored-position units.")]
        [SerializeField] protected float m_DefaultShakeMagnitude = 12f;
        [Tooltip("Default number of shake points.")]
        [SerializeField] protected int m_DefaultShakePoints = 4;

        [Header("Wiggle")]
        [Tooltip("Default wiggle angle in degrees.")]
        [SerializeField] protected float m_DefaultWiggleAngle = 12f;

        [Header("Bounce")]
        [Tooltip("Default bounce peak multiplier.")]
        [SerializeField] protected float m_DefaultBounceUpScale = 1.2f;
        [Tooltip("Default bounce undershoot multiplier.")]
        [SerializeField] protected float m_DefaultBounceDownScale = 0.9f;

        private readonly List<MotionEffect> m_PositionEffects = new List<MotionEffect>();
        private readonly List<MotionEffect> m_RotationEffects = new List<MotionEffect>();
        private readonly List<MotionEffect> m_ScaleEffects = new List<MotionEffect>();

        private RectTransform m_CanvasRect;

        private Vector2 m_RestAnchoredPosition;
        private float m_RestRotation;
        private Vector2 m_RestScale = Vector2.one;

        /// <summary>
        /// The driven RectTransform.
        /// </summary>
        public RectTransform DrivenRectTransform => m_RectTransform;

        /// <summary>
        /// Initializes cached references and resting transform state.
        /// </summary>
        protected virtual void Awake()
        {
            if (m_RectTransform == null) {
                m_RectTransform = transform as RectTransform;
            }

            if (m_RectTransform == null) {
                Debug.LogError("UIMover requires a RectTransform.", this);
                enabled = false;
                return;
            }

            CacheCanvasRect();
            CacheRestStateFromTransform();
        }

        /// <summary>
        /// Updates active effects and applies the final blended transform.
        /// </summary>
        protected virtual void Update()
        {
            if (m_RectTransform == null) { return; }

            var dt = Time.unscaledDeltaTime;
            if (dt <= 0f) { return; }

            var positionOffset = EvaluateEffects(m_PositionEffects, dt, EffectChannel.Position, ref m_RestAnchoredPosition);
            var rotationOffset = EvaluateEffects(m_RotationEffects, dt, EffectChannel.Rotation, ref m_RestRotation).x;
            var scaleOffset = EvaluateEffects(m_ScaleEffects, dt, EffectChannel.Scale, ref m_RestScale);

            if (m_UseCircularPositionClamp) {
                positionOffset = CircularizePositionOffset(positionOffset);
            }

            var finalPosition = m_RestAnchoredPosition + positionOffset;
            var finalRotation = m_RestRotation + rotationOffset;
            var finalScale = m_RestScale + scaleOffset;

            if (m_ClampToCanvas) {
                finalPosition = ClampAnchoredPositionToCanvas(finalPosition);
            }

            ApplyTransform(finalPosition, finalRotation, finalScale);
        }

        /// <summary>
        /// Clears all active effects and refreshes the resting state from the current transform.
        /// </summary>
        public virtual void ClearCommands()
        {
            m_PositionEffects.Clear();
            m_RotationEffects.Clear();
            m_ScaleEffects.Clear();

            CacheRestStateFromTransform();
        }

        /// <summary>
        /// Re-caches the current canvas rect if available.
        /// </summary>
        public virtual void CacheCanvasRect()
        {
            if (m_Canvas != null) {
                m_CanvasRect = m_Canvas.transform as RectTransform;
                return;
            }

            var parentCanvas = GetComponentInParent<Canvas>();
            if (parentCanvas != null) {
                m_Canvas = parentCanvas;
                m_CanvasRect = parentCanvas.transform as RectTransform;
            }
        }

        /// <summary>
        /// Caches the current RectTransform values as the resting state.
        /// </summary>
        public virtual void CacheRestStateFromTransform()
        {
            if (m_RectTransform == null) { return; }

            m_RestAnchoredPosition = m_RectTransform.anchoredPosition;
            m_RestRotation = NormalizeAngle(m_RectTransform.localEulerAngles.z);

            var localScale = m_RectTransform.localScale;
            m_RestScale = new Vector2(localScale.x, localScale.y);
        }

        /// <summary>
        /// Immediately snaps the resting position.
        /// </summary>
        public virtual void SnapMove(Vector2 anchoredPosition)
        {
            m_RestAnchoredPosition = m_ClampToCanvas
                ? ClampAnchoredPositionToCanvas(anchoredPosition)
                : anchoredPosition;
        }

        /// <summary>
        /// Adds a committed movement effect that lerps toward the supplied anchored-position delta.
        /// Multiple movement effects can combine into diagonal motion.
        /// </summary>
        public virtual void LinearMove(Vector2 delta)
        {
            AddEffect(m_PositionEffects, new MotionEffect
            {
                Channel = EffectChannel.Position,
                Points = new[] { delta },
                DurationPerPoint = m_DefaultDurationPerPoint,
                CommitOnComplete = true
            }, m_MaxPositionEffects);
        }

        /// <summary>
        /// Adds a committed movement effect using local orientation to rotate the delta before applying it.
        /// </summary>
        public virtual void DeltaMove(Vector2 localDelta)
        {
            if (m_RectTransform == null) { return; }

            var rotatedDelta = RotateVector(localDelta * m_TranslateMultiplier, m_RectTransform.localEulerAngles.z);
            LinearMove(rotatedDelta);
        }

		/// <summary>
		/// Immediately snaps the resting rotation and clears active rotation effects.
		/// </summary>
		public virtual void SnapRotation(float zRotation)
		{
			m_RotationEffects.Clear();
			m_RestRotation = NormalizeAngle(zRotation);

			if (m_RectTransform == null) { return; }

			var euler = m_RectTransform.localEulerAngles;
			euler.z = m_RestRotation;
			m_RectTransform.localEulerAngles = euler;
		}

        /// <summary>
        /// Adds a committed rotation effect using a delta angle in degrees.
        /// </summary>
        public virtual void DeltaRotate(float deltaAngle)
        {
            AddEffect(m_RotationEffects, new MotionEffect
            {
                Channel = EffectChannel.Rotation,
                Points = new[] { new Vector2(deltaAngle * m_RotationMultiplier, 0f) },
                DurationPerPoint = m_DefaultDurationPerPoint,
                CommitOnComplete = true
            }, m_MaxRotationEffects);
        }

        /// <summary>
        /// Adds a committed uniform scale effect using a delta from 1.
        /// For example, 0.25 means scale toward +25%.
        /// </summary>
        public virtual void LinearScale(float deltaUniformScale)
        {
            AddEffect(m_ScaleEffects, new MotionEffect
            {
                Channel = EffectChannel.Scale,
                Points = new[] { new Vector2(deltaUniformScale, deltaUniformScale) },
                DurationPerPoint = m_DefaultDurationPerPoint,
                CommitOnComplete = true
            }, m_MaxScaleEffects);
        }

        /// <summary>
        /// Adds a temporary additive shake around zero.
        /// </summary>
        public virtual void Shake()
        {
            Shake(m_DefaultShakeMagnitude, m_DefaultShakePoints);
        }

        /// <summary>
        /// Adds a temporary additive shake around zero.
        /// </summary>
        public virtual void Shake(float magnitude, int points)
        {
            points = Mathf.Max(1, points);

            var packet = new Vector2[points + 1];
            for (int i = 0; i < points; i++) {
                packet[i] = Random.insideUnitCircle * magnitude;
            }

            packet[packet.Length - 1] = Vector2.zero;

            AddEffect(m_PositionEffects, new MotionEffect
            {
                Channel = EffectChannel.Position,
                Points = packet,
                DurationPerPoint = m_DefaultDurationPerPoint,
                CommitOnComplete = false
            }, m_MaxPositionEffects);
        }

        /// <summary>
        /// Adds a temporary additive bounce scale effect.
        /// </summary>
        public virtual void Bounce()
        {
            Bounce(m_DefaultBounceUpScale, m_DefaultBounceDownScale);
        }

        /// <summary>
        /// Adds a temporary additive bounce scale effect.
        /// </summary>
        public virtual void Bounce(float upScale, float downScale)
        {
            AddEffect(m_ScaleEffects, new MotionEffect
            {
                Channel = EffectChannel.Scale,
                Points = new[]
                {
                    new Vector2(upScale - 1f, upScale - 1f),
                    new Vector2(downScale - 1f, downScale - 1f),
                    Vector2.zero
                },
                DurationPerPoint = m_DefaultDurationPerPoint,
                CommitOnComplete = false
            }, m_MaxScaleEffects);
        }

        /// <summary>
        /// Adds a temporary additive rotational wiggle.
        /// </summary>
        public virtual void Wiggle()
        {
            Wiggle(m_DefaultWiggleAngle);
        }

        /// <summary>
        /// Adds a temporary additive rotational wiggle.
        /// </summary>
        public virtual void Wiggle(float angle)
        {
            AddEffect(m_RotationEffects, new MotionEffect
            {
                Channel = EffectChannel.Rotation,
                Points = new[]
                {
                    new Vector2(angle, 0f),
                    new Vector2(-angle, 0f),
                    Vector2.zero
                },
                DurationPerPoint = m_DefaultDurationPerPoint,
                CommitOnComplete = false
            }, m_MaxRotationEffects);
        }

        /// <summary>
        /// Adds an effect to the specified channel list, dropping the oldest effect if the list is already full.
        /// </summary>
        protected virtual void AddEffect(List<MotionEffect> effects, MotionEffect effect, int maxCount)
        {
            if (effect.Points == null || effect.Points.Length == 0) {
                return;
            }

            maxCount = Mathf.Max(1, maxCount);

            while (effects.Count >= maxCount) {
                effects.RemoveAt(0);
            }

            effects.Add(effect);
        }

        /// <summary>
        /// Evaluates a channel list, removes completed effects, and returns the summed offset.
        /// Completed committed effects are baked into the supplied resting state.
        /// </summary>
        protected virtual Vector2 EvaluateEffects(
			List<MotionEffect> effects,
			float dt,
			EffectChannel channel,
			ref Vector2 restValue
		){
			var sum = Vector2.zero;

			for (int i = effects.Count - 1; i >= 0; i--) {
				var effect = effects[i];
				var current = EvaluateCurrentOffset(ref effect, channel, dt, out var finished);

				if (finished) {
					if (effect.CommitOnComplete) {
						var final = effect.Points[effect.Points.Length - 1];
						restValue += final;
					} else {
						sum += current;
					}

					effects.RemoveAt(i);
				} else {
					sum += current;
					effects[i] = effect;
				}
			}

			return sum;
		}

        /// <summary>
        /// Evaluates a channel list for a scalar resting value and returns the summed offset in X.
        /// </summary>
        protected virtual Vector2 EvaluateEffects(
			List<MotionEffect> effects,
			float dt,
			EffectChannel channel,
			ref float restValue
		){
			var sum = Vector2.zero;

			for (int i = effects.Count - 1; i >= 0; i--) {
				var effect = effects[i];
				var current = EvaluateCurrentOffset(ref effect, channel, dt, out var finished);

				if (finished) {
					if (effect.CommitOnComplete) {
						var final = effect.Points[effect.Points.Length - 1];
						restValue += final.x;
					} else {
						sum += current;
					}

					effects.RemoveAt(i);
				} else {
					sum += current;
					effects[i] = effect;
				}
			}

			return sum;
		}

        /// <summary>
        /// Evaluates the current offset contributed by an effect. Effects always interpolate from zero through their packet points.
        /// </summary>
        protected virtual Vector2 EvaluateCurrentOffset(
            ref MotionEffect effect,
            EffectChannel channel,
            float dt,
            out bool finished)
        {
            finished = true;

            if (effect.Points == null || effect.Points.Length == 0) {
                return Vector2.zero;
            }

            effect.Elapsed += dt;

            var duration = Mathf.Max(0.0001f, effect.DurationPerPoint);
            var segmentIndex = Mathf.FloorToInt(effect.Elapsed / duration);
            var segmentT = (effect.Elapsed % duration) / duration;

            if (segmentIndex >= effect.Points.Length) {
                return effect.Points[effect.Points.Length - 1];
            }

            finished = false;

            Vector2 from = segmentIndex == 0 ? Vector2.zero : effect.Points[segmentIndex - 1];
            var to = effect.Points[segmentIndex];

            if (channel == EffectChannel.Rotation) {
                return new Vector2(Mathf.LerpAngle(from.x, to.x, segmentT), 0f);
            }

            return Vector2.LerpUnclamped(from, to, segmentT);
        }

        /// <summary>
        /// Converts a square-bounded input offset into a circular-bounded offset so diagonal motion
        /// does not move faster than pure linear motion.
        /// </summary>
        protected virtual Vector2 CircularizePositionOffset(Vector2 offset)
        {
            var dominant = Mathf.Max(Mathf.Abs(offset.x), Mathf.Abs(offset.y));
            var magnitude = offset.magnitude;

            if (dominant <= 0f || magnitude <= dominant) {
                return offset;
            }

            return offset / magnitude * dominant;
        }

        /// <summary>
        /// Applies the final transform values to the RectTransform.
        /// </summary>
        protected virtual void ApplyTransform(Vector2 anchoredPosition, float rotation, Vector2 scale)
        {
            m_RectTransform.anchoredPosition = anchoredPosition;

            var euler = m_RectTransform.localEulerAngles;
            euler.z = rotation;
            m_RectTransform.localEulerAngles = euler;

            var localScale = m_RectTransform.localScale;
            localScale.x = scale.x;
            localScale.y = scale.y;
            m_RectTransform.localScale = localScale;
        }

        /// <summary>
        /// Clamps anchored position inside the acting canvas when possible.
        /// </summary>
        protected virtual Vector2 ClampAnchoredPositionToCanvas(Vector2 anchoredPosition)
        {
            if (m_RectTransform == null || m_CanvasRect == null) {
                return anchoredPosition;
            }

            var canvasRect = m_CanvasRect.rect;
            var selfRect = m_RectTransform.rect;

            var halfWidth = selfRect.width * 0.5f;
            var halfHeight = selfRect.height * 0.5f;

            var minX = canvasRect.xMin + halfWidth;
            var maxX = canvasRect.xMax - halfWidth;
            var minY = canvasRect.yMin + halfHeight;
            var maxY = canvasRect.yMax - halfHeight;

            anchoredPosition.x = Mathf.Clamp(anchoredPosition.x, minX, maxX);
            anchoredPosition.y = Mathf.Clamp(anchoredPosition.y, minY, maxY);

            return anchoredPosition;
        }

        /// <summary>
        /// Rotates a Vector2 by the provided angle in degrees.
        /// </summary>
        protected static Vector2 RotateVector(Vector2 vector, float angleDegrees)
        {
            var radians = angleDegrees * Mathf.Deg2Rad;
            var sin = Mathf.Sin(radians);
            var cos = Mathf.Cos(radians);

            return new Vector2(
                vector.x * cos - vector.y * sin,
                vector.x * sin + vector.y * cos
            );
        }

        /// <summary>
        /// Normalizes an angle into the signed range expected for interpolation.
        /// </summary>
        protected static float NormalizeAngle(float angle)
        {
            angle %= 360f;
            if (angle > 180f) {
                angle -= 360f;
            } else if (angle < -180f) {
                angle += 360f;
            }

            return angle;
        }
    }
}