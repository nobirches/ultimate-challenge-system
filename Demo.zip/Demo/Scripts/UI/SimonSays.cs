﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
    using Opsive.Shared.Audio;
    using UnityEngine;
    using UnityEngine.UI;

    /// <summary>Simon Says challenge using Password input with a teach-before-repeat flow.</summary>
    public class SimonSays : Password
    {
        public enum TeachMode { FullSequence, Incremental }

        [SerializeField] private Button[] m_Buttons;
        [SerializeField] private TeachMode m_TeachMode;
        [SerializeField, Min(0f)] private float m_StartDelay = 1f;
        [SerializeField, Min(0.05f)] private float m_TeachStepTime = 0.5f;

        private readonly Color m_Normal = Color.white;
        private readonly Color m_Teach = Color.yellow;
        private readonly Color m_Right = Color.green;
        private readonly Color m_Wrong = Color.red;

        private bool m_Waiting, m_Teaching, m_Failed, m_Solved;
        private int m_TeachIndex, m_TargetLength;
        private float m_Timer;
        private ColorBlock[] m_Defaults;

        protected override void InitializeInternal() {
            m_Defaults = new ColorBlock[m_Buttons == null ? 0 : m_Buttons.Length];

            for (int i = 0; i < m_Defaults.Length; i++) {
                m_Defaults[i] = m_Buttons[i] != null ? m_Buttons[i].colors : ColorBlock.defaultColorBlock;
            }
        }

        protected override void StartChallengeInternal(in Challenge challenge) {
            m_ExpectedCode = challenge.ExpectedCode ?? string.Empty;
            m_MaxCharacters = Mathf.Max(1, m_ExpectedCode.Length);
            BeginRound(m_TeachMode == TeachMode.Incremental ? 1 : m_ExpectedCode.Length);
        }

        protected override void StopChallengeInternal() {
            m_Waiting = m_Teaching = false;
            RestoreButtons();
            Clear();
        }

        protected override bool ResetInternal() {
            BeginRound(m_TeachMode == TeachMode.Incremental ? 1 : m_ExpectedCode.Length);
            return true;
        }

        protected override void UpdateInternal() {
            if (m_Failed || m_Solved || (!m_Waiting && !m_Teaching)) { return; }

            m_Timer -= Time.unscaledDeltaTime;

            if (m_Waiting) {
                SetDisplay("Watch");

                if (m_Timer <= 0f) {
                    m_Waiting = false;
                    m_Teaching = true;
                    m_TeachIndex = 0;
                    TeachNext();
                }

                return;
            }

            if (m_Timer <= 0f) {
                TeachNext();
            }
        }

        protected override void UnityButtonInternal(object command) {
            if (m_Waiting || m_Teaching || m_Failed || m_Solved) { return; }
            if (!TryGetInput(command, out var input)) { return; }

			m_Audio.PlayAtPosition(m_SubjectTransform.position);
            AppendInput(input);

            var slice = m_ExpectedCode.Substring(0, m_TargetLength);
            if (!slice.StartsWith(m_CurrentInput, System.StringComparison.Ordinal)) {
                m_Failed = true;
                m_RemainingTime = 0f;
                RestoreButtons();
                SetDisplay("Wrong");
                return;
            }

            if (m_CurrentInput.Length < slice.Length) {
                PaintPressed();
                return;
            }

            if (m_TeachMode == TeachMode.Incremental && m_TargetLength < m_ExpectedCode.Length) {
                BeginRound(m_TargetLength + 1);
                return;
            }

            m_Solved = true;
            RestoreButtons();
            SetDisplay("Correct");
        }

        protected override bool SubmitInternal() => m_Solved && !m_Failed;
        protected override bool CanAutoSubmit() => m_Solved || m_Failed;

        private void BeginRound(int length) {
            Clear();

            m_TargetLength = Mathf.Clamp(length, 0, m_ExpectedCode.Length);
            m_TeachIndex = 0;
            m_Failed = m_Solved = false;
            m_Waiting = true;
            m_Teaching = false;
            m_Timer = m_StartDelay;

            RestoreButtons();
            PaintNormal(m_Normal);
            SetDisplay("Watch");
        }

        private void TeachNext() {
            PaintNormal(m_Normal);

            if (m_TeachIndex >= m_TargetLength) {
                m_Teaching = false;
                PaintPressed();
                SetDisplay("Repeat");
                return;
            }

            var index = m_ExpectedCode[m_TeachIndex] - '0';
            if (index >= 0 && m_Buttons != null && index < m_Buttons.Length && m_Buttons[index] != null) {
                PaintTeaching(m_Buttons[index]);

                if (m_SubjectTransform != null && m_Audio != null) {
                    m_Audio.PlayAtPosition(m_SubjectTransform.position);
                }
            }

            SetDisplay(m_ExpectedCode[m_TeachIndex].ToString());
            m_TeachIndex++;
            m_Timer = m_TeachStepTime;
        }

        private void PaintPressed() {
            if (m_Buttons == null) { return; }

            var next = m_CurrentInput.Length < m_TargetLength
                ? m_ExpectedCode[m_CurrentInput.Length] - '0'
                : -1;

            for (int i = 0; i < m_Buttons.Length; i++) {
                if (m_Buttons[i] == null) { continue; }

                var c = m_Buttons[i].colors;
                c.normalColor = m_Normal;
                c.highlightedColor = m_Normal;
                c.selectedColor = m_Normal;
                c.pressedColor = i == next ? m_Right : m_Wrong;
                m_Buttons[i].colors = c;
            }
        }

        private void PaintNormal(Color color) {
            if (m_Buttons == null) { return; }

            for (int i = 0; i < m_Buttons.Length; i++) {
                PaintNormal(m_Buttons[i], color);
            }
        }

        private void PaintNormal(Button button, Color color) {
            if (button == null) { return; }

            var c = button.colors;
            c.normalColor = color;
            c.highlightedColor = color;
            c.selectedColor = color;
            button.colors = c;
        }

        private void PaintTeaching(Button button) {
            if (button == null) { return; }

            var c = button.colors;
            c.normalColor = m_Teach;
            c.highlightedColor = m_Teach;
            c.selectedColor = m_Teach;
            c.pressedColor = m_Teach;
            button.colors = c;
        }

        private void RestoreButtons() {
            if (m_Buttons == null || m_Defaults == null) { return; }

            for (int i = 0; i < m_Buttons.Length && i < m_Defaults.Length; i++) {
                if (m_Buttons[i] != null) {
                    m_Buttons[i].colors = m_Defaults[i];
                }
            }
        }
    }
}