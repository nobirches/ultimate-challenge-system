﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
	using Opsive.UltimateCharacterController.AddOns.Challenge.Interactive;
	using Opsive.Shared.UI;
	using UnityEngine.UI;
	using UnityEngine;

    /// <summary>
    /// Simple test challenge that succeeds when the expected code is matched by ui button inputs.
    /// </summary>
    public class Password : InteractiveChallengeBase
	{
		[SerializeField] protected Opsive.Shared.Audio.AudioClipSet m_Audio;
		[SerializeField] protected Shared.UI.Text m_Display;

		protected string m_CurrentInput = string.Empty;
		protected string m_ExpectedCode = string.Empty;
		protected int m_MaxCharacters;

		protected override void StartChallengeInternal(in Challenge challenge) {
			m_ExpectedCode = challenge.ExpectedCode ?? string.Empty;
			m_MaxCharacters = Mathf.Max(1, m_ExpectedCode.Length);
			Clear();
		}

		protected override void StopChallengeInternal() => Clear();

		protected override bool SubmitInternal() {
			if (string.Equals(m_CurrentInput, m_ExpectedCode, System.StringComparison.Ordinal)) {
				return true;
			}

			m_RemainingTime = 0f;
			return false;
		}

		protected override bool ResetInternal() {
			Clear();
			return true;
		}

		protected override bool CanAutoSubmit() {
			return base.CanAutoSubmit() && m_MaxCharacters > 0 && m_CurrentInput.Length >= m_MaxCharacters;
		}

		protected override void UnityButtonInternal(object command) {
			m_Audio.PlayAtPosition(m_SubjectTransform.position);

			if (TryGetInput(command, out var input)) {
				AppendInput(input);
			}
		}

		protected virtual bool TryGetInput(object command, out string input) {
			input = null;

			if (command is int digit) {
				input = Mathf.Clamp(digit, 0, 9).ToString();
				return true;
			}

			if (command is string str) {
				if (string.IsNullOrEmpty(str)) { return false; }

				if (string.Equals(str, "Clear", System.StringComparison.OrdinalIgnoreCase)) {
					Clear();
					return false;
				}

				input = str;
				return true;
			}

			return false;
		}

		protected virtual void AppendInput(string input) {
			if (string.IsNullOrEmpty(input)) { return; }

			foreach (var ch in input) {
				if (!char.IsDigit(ch)) { continue; }
				if (m_MaxCharacters > 0 && m_CurrentInput.Length >= m_MaxCharacters) { break; }

				m_CurrentInput += ch;
			}

			UpdateDisplay();
		}

		protected virtual void Clear() {
			m_CurrentInput = string.Empty;
			UpdateDisplay();
		}

		protected virtual void UpdateDisplay() {
			if (m_Display.text != null) {
				m_Display.text = m_CurrentInput;
			}
		}

		protected void SetDisplay(string text) {
			if (m_Display.text != null) {
				m_Display.text = text ?? string.Empty;
			}
		}
	}
}