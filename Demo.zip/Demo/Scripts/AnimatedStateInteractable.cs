﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
    using System.Collections.Generic;
    using Opsive.Shared.Game;
    using Opsive.Shared.StateSystem;
	using Opsive.UltimateCharacterController.Character.Abilities;
    using Opsive.UltimateCharacterController.Items.Actions.Impact;
    using Opsive.UltimateCharacterController.Traits;
    using Opsive.UltimateCharacterController.Utility;
    using UnityEngine;

    /// <summary>
	/// Requires an Interactable that sends strings to execute commands.
    /// </summary>
    [DisallowMultipleComponent]
    public class AnimatedStateInteractable : StateBehavior, IInteractableTarget, IInteractableCommandTarget, IInteractableMessage
    {
	#region Nested Types
		/// <summary>The mapped command name + Parameter value.</summary>
        private enum Param { None, Bool, Int, Float, Trigger }
        /// <summary>Controls how bool animator parameters behave when triggered.</summary>
		public enum BoolMode { Toggle, Switch, Exclude }
        /// <summary>Controls how float animator parameters behave when triggered.</summary>
		public enum FloatMode { Additive, Invertive, Exclusive }
        /// <summary>Controls how int animator parameters change when triggered.</summary>
		public enum IntMode { Counter, ResetCounter, Absolute }

		/// <summary>Describes the ImpactActionGroup + settings for animated interactables.</summary>
        [System.Serializable]
        public class InteractActionGroup {
            [Tooltip("Optional string message for the Interact ability.")]
            [SerializeField] protected string m_ActionMessage;
            [Tooltip("If false, the group's event will only fire once per interaction even on looping clips.")]
            [SerializeField] private bool m_AllowLoopEvents = false;
            [Tooltip("Optional override ImpactActionGroup asset used instead of the default group.")]
            [SerializeField] private ImpactActionGroupObject m_ActionObject;
            [Tooltip("Timing for the ImpactActionGroup (time-based or animation-event-based).")]
            [SerializeField] private AnimationEventTrigger m_ActionEvent = new AnimationEventTrigger(false, 0f);

            public string                    ActionMessage  { get => m_ActionMessage;  set => m_ActionMessage = value; }
            public bool                      AllowLoopEvents { get => m_AllowLoopEvents; set => m_AllowLoopEvents = value; }
            public ImpactActionGroupObject   ActionObject   { get => m_ActionObject;   set => m_ActionObject = value; }
            public AnimationEventTrigger     ActionEvent    { get => m_ActionEvent;    set => m_ActionEvent = value; }
        }

		/// <summary>Describes an individual float blend parameter and its transition snapshot.</summary>
        private struct FloatBlend {
            public float From;
            public float To;
            public float Elapsed;
            public bool  Active;
        }
	#endregion

	#region Fields
		/*** Serialized Fields ***/
        [Tooltip(
			"If this value is set, it will override any incoming command and always execute this behavior.\n" +
			"Use this to force a specific interaction state (e.g. locked, broken, disabled)."
		)]
		[SerializeField, HideInInspector] private string m_DefaultCommand;
		[Tooltip(
			"If true, the interactable forgets its command/state memory after the requested enable/disable action has completed.\n" +
			"Useful for one-shot commands that should fire feedback without permanently latching animator/state memory."
		)]
		[SerializeField, HideInInspector] private bool m_OneShotCommands;
		[Tooltip("Fallback message shown by AbilityMessage() when the interacted command is not a Bool param (or has no mapped animator param).")]
		[SerializeField, HideInInspector] private string m_DefaultMessage;

		[Tooltip(
			"How Bool animator params behave when Interact triggers a Bool command:\n" +
			"• Toggle: Flip ONLY this bool (true↔false). Others unchanged.\n" +
			"• Switch: If ANY bool is currently true → clear ALL bools (fires Disable). If none are true → set THIS bool true (fires Enable).\n" +
			"• Exclude: Clear ALL bools, then set THIS bool true (always ends with only this active; fires Enable)."
		)]
		[SerializeField, HideInInspector] private BoolMode m_BoolMode = BoolMode.Toggle;

		[Tooltip(
			"How Float animator params behave (treated like 0..1 channels with optional blending):\n" +
			"• Exclude: Turning this ON blends other float channels to 0, this to 1. Turning OFF blends only this to 0.\n" +
			"• Additive: Only this channel blends 0↔1. Other float channels are untouched.\n" +
			"• Invertive: OFF→ON sets this to 1 and all other float channels to 0. ON→OFF sets this to 0 and all others to 1."
		)]
		[SerializeField, HideInInspector] private FloatMode m_FloatMode = FloatMode.Additive;

		[Tooltip(
			"Seconds to blend float values when turning float channels on/off.\n" +
			"Used by Exclude/Additive/Invertive float modes (min clamped)."
		)]
		[SerializeField, HideInInspector] private float m_FloatBlendDuration = 0.25f;

		[Tooltip(
			"How Int animator params advance when Interact triggers an Int command:\n" +
			"• Counter: +1 each time, clamped at Target Value (stops increasing).\n" +
			"• ResetCounter: +1 each time, wraps back to 0 after exceeding Target Value.\n" +
			"• Absolute: Always sets the int directly to Target Value."
		)]
		[SerializeField, HideInInspector] private IntMode m_IntMode = IntMode.Counter;

		[Tooltip(
			"Meaning depends on Int Mode:\n" +
			"• Counter / ResetCounter: maximum count (values go 0..Target Value).\n" +
			"• Absolute: value to set every time (can be negative).\n" +
			"Note: Counter modes clamp Target Value to >= 0 at runtime."
		)]
		[SerializeField, HideInInspector] private int m_TargetValue = 3;
		[Tooltip("Should Impact Actions affect the character interacting with this object?")]
		[SerializeField, HideInInspector] private bool m_UseCharacterImpact;

        [Space(10)]
        [Tooltip("Actions that occur when the interaction command is True/enabled.")]
        [SerializeField] private InteractActionGroup m_EnableActionOverride = new InteractActionGroup();
        [Tooltip("Default ImpactActionGroup used when enabling.")]
        [SerializeField] private ImpactActionGroup m_EnableAction;
        [Tooltip("Actions that occur when the interaction command is False/disabled.")]
        [SerializeField] private InteractActionGroup m_DisableActionOverride = new InteractActionGroup();
        [Tooltip("Default ImpactActionGroup used when disabling.")]
        [SerializeField] private ImpactActionGroup m_DisableAction;

		/*** Runtime Fields ***/
        [System.NonSerialized] private GameObject m_GameObject;
        private Animator m_Animator;

        private static uint s_NextImpactSourceID = 1;
        private int m_LastInteractedCommandIndex = -1;

        private bool m_EnableEventFiredThisInteract;
        private bool m_DisableEventFiredThisInteract;

        private Dictionary<string, int> m_CommandIndexLookup;
        private Param[] m_CommandParams;
        private int[]   m_CommandHashes;

        private Transform             m_ImpactTarget;
        private Collider              m_TargetCollider;
        private ImpactCallbackContext m_CachedCtx;
        private ImpactCollisionData   m_CachedCollisionData;
        private ImpactDamageData      m_NoopDamageData = new ImpactDamageData();

        private FloatBlend[]        m_FloatBlends;
        private ScheduledEventBase  m_FloatBlendEvent;
        private float               m_LastFloatBlendTime;

		/*** Public Properties ***/
		public string DefaultCommand	{ get => m_DefaultCommand; set => m_DefaultCommand = value; }
		public bool OneShotCommand		{ get => m_OneShotCommands; set => m_OneShotCommands = value; }

        public bool UseTargetImpact 	{ get => m_UseCharacterImpact; set => m_UseCharacterImpact = value; }
        public BoolMode BoolType 		{ get => m_BoolMode; set => m_BoolMode = value; }
        public FloatMode FloatType 		{ get => m_FloatMode; set => m_FloatMode = value; }
        public float FloatBlendDuration { get => Mathf.Max(0.02f, m_FloatBlendDuration); set => m_FloatBlendDuration = value; }
        public IntMode IntType 			{ get => m_IntMode; set => m_IntMode = value; }
        public int IntMaxRange 			{ get => m_TargetValue; set => m_TargetValue = value; }

		public ImpactActionGroupObject EnableObject   { get => m_EnableActionOverride.ActionObject; set => m_EnableActionOverride.ActionObject = value; }
        public AnimationEventTrigger   EnableEvent 	  { get => m_EnableActionOverride.ActionEvent; set => m_EnableActionOverride.ActionEvent = value; }
        public string				   EnableMessage  { get => m_EnableActionOverride.ActionMessage; set => m_EnableActionOverride.ActionMessage = value; }
		public bool					   EnableLoop	  { get => m_EnableActionOverride.AllowLoopEvents; set => m_EnableActionOverride.AllowLoopEvents = value; }

		public ImpactActionGroupObject DisableObject  { get => m_DisableActionOverride.ActionObject; set => m_DisableActionOverride.ActionObject = value; }
        public AnimationEventTrigger   DisableEvent	  { get => m_DisableActionOverride.ActionEvent; set => m_DisableActionOverride.ActionEvent = value; }
		public string				   DisableMessage { get => m_DisableActionOverride.ActionMessage; set => m_DisableActionOverride.ActionMessage = value; }
		public bool					   DisableLoop	  { get => m_DisableActionOverride.AllowLoopEvents; set => m_DisableActionOverride.AllowLoopEvents = value; }
	#endregion

	#region Unity Lifecycle
		/// <summary>Caches references, initializes command mappings, action groups, and animation events.</summary>
        protected override void Awake() {
            base.Awake();

            m_GameObject = gameObject;
            m_Animator   = GetComponent<Animator>();

            InitializeCommandMappings();
            InitializeDefaultActionGroup();
        }

		/// <summary>Builds lookup tables mapping states to animator parameters and blend data.</summary>
		private void InitializeCommandMappings() {
			var animatorParams = m_Animator != null ? m_Animator.parameters : null;
			var count = animatorParams != null ? animatorParams.Length : 0;

			m_CommandHashes = new int[count];
			m_CommandParams = new Param[count];
			m_CommandIndexLookup = new Dictionary<string, int>(count);
			m_FloatBlends = new FloatBlend[count];

			for (int i = 0; i < count; ++i) {
				var param = animatorParams[i];
				if (string.IsNullOrEmpty(param.name)) {
					m_CommandParams[i] = Param.None;
					continue;
				}

				m_CommandHashes[i] = param.nameHash;
				m_CommandIndexLookup[param.name] = i;

				switch (param.type) {
					case AnimatorControllerParameterType.Bool:
						m_CommandParams[i] = Param.Bool;
						break;
					case AnimatorControllerParameterType.Int:
						m_CommandParams[i] = Param.Int;
						break;
					case AnimatorControllerParameterType.Float:
						m_CommandParams[i] = Param.Float;
						break;
					case AnimatorControllerParameterType.Trigger:
						m_CommandParams[i] = Param.Trigger;
						break;
					default:
						m_CommandParams[i] = Param.None;
						break;
				}
			}
		}

		/// <summary>Initializes default ImpactActionGroups and resets per-interaction flags.</summary>
        private void InitializeDefaultActionGroup() {
            if (m_NoopDamageData == null) m_NoopDamageData = new ImpactDamageData();
            m_NoopDamageData.Reset();

            m_EnableEventFiredThisInteract  = true;
            m_DisableEventFiredThisInteract = true;

            if (m_EnableAction != null) {
				m_EnableAction.Initialize(m_GameObject, null);
            }
			if (m_DisableAction != null) {
				m_DisableAction.Initialize(m_GameObject, null);
			}
		}

		/// <summary>Cancels any active float blending when the object is disabled.</summary>
        private void OnDisable() {
			ResetInteract();
        }

		/// <summary>Registers animation events and cancels blending on enable.</summary>
		private void OnEnable() {
			ResetInteract();
			if (m_GameObject != null) {
				m_EnableActionOverride.ActionEvent.RegisterUnregisterAnimationEvent(true, m_GameObject, "OnAnimatorEnabled",  OnEnableActionEvent);
				m_DisableActionOverride.ActionEvent.RegisterUnregisterAnimationEvent(true, m_GameObject, "OnAnimatorDisabled", OnDisableActionEvent);
			}
		}

		/// <summary>Unregisters animation events and cancels blending on destruction.</summary>
        private void OnDestroy() {
			ResetInteract();
            if (m_GameObject != null) {
                m_EnableActionOverride.ActionEvent.RegisterUnregisterAnimationEvent(false, m_GameObject, "OnAnimatorEnabled",  OnEnableActionEvent);
                m_DisableActionOverride.ActionEvent.RegisterUnregisterAnimationEvent(false, m_GameObject, "OnAnimatorDisabled", OnDisableActionEvent);
            }
        }
	#endregion

	#region Interaction API
		/// <summary>Returns the appropriate interact prompt message for the last interacted command.</summary>
		public string AbilityMessage() {
            if (m_Animator == null) return string.Empty;

            if (m_LastInteractedCommandIndex < 0 || m_LastInteractedCommandIndex >= m_CommandHashes.Length)
                return m_DefaultMessage;

            int hash = m_CommandHashes[m_LastInteractedCommandIndex];
            if (hash == 0) return m_EnableActionOverride.ActionMessage;

            var kind = m_CommandParams[m_LastInteractedCommandIndex];
            if (kind == Param.Bool) {
                bool current = m_Animator.GetBool(hash);
                return current ? m_DisableActionOverride.ActionMessage : m_EnableActionOverride.ActionMessage;
            }
            return m_DefaultMessage;
        }

		/// <summary>Returns false while enable/disable actions are still pending.</summary>
        public bool CanInteract(GameObject character, Interact interactAbility) {
            var enablePending  = HasEnableActions()  && !m_EnableEventFiredThisInteract;
            var disablePending = HasDisableActions() && !m_DisableEventFiredThisInteract;
            return !(enablePending || disablePending);
        }

		/// <summary>Default Interaction path if Command Name is not specified.</summary>
		public void Interact(GameObject character, Interact interactAbility) {
			Interact(character, interactAbility, m_DefaultCommand);
		}

		/// <summary>Handles interaction by applying the mapped animator parameter behavior for the given Command Name.</summary>
        public void Interact(GameObject character, Interact interactAbility, string command) {
            if (!string.IsNullOrEmpty(m_DefaultCommand)) {
				command = m_DefaultCommand;
			}

			if (string.IsNullOrEmpty(command)) {
                Debug.Log($"[AnimatedInteractable] Interact called on '{gameObject.name}' with empty command name.");
                return;
            }

            if (!TryGetCommandIndexAndHash(command, out var index, out var hash)) {
                Debug.Log($"[AnimatedInteractable] Interact('{command}') on '{gameObject.name}' is not mapped in the animator.");
                return;
            }

            m_LastInteractedCommandIndex = index;
			m_ImpactTarget   = (character != null && m_UseCharacterImpact) ? character.transform : m_GameObject.transform;
            m_TargetCollider = m_ImpactTarget.gameObject.GetComponentInChildren<Collider>();

            var type = m_CommandParams[index];
            switch (type) {
                case Param.Bool:
                    HandleBoolParam(index, hash);
                    break;
                case Param.Float:
                    HandleFloatParam(index, hash);
                    break;
                case Param.Int:
                    HandleIntParam(index, hash);
                    break;
                case Param.Trigger:
                    HandleTriggerParam(index, hash);
                    break;
                case Param.None:
                default:
                    RequestEnableAction();
                    break;
            }
        }

		/// <summary>Resets animator parameters, clears pending actions, and stops float blending.</summary>
        public void ResetInteract() {
            m_LastInteractedCommandIndex	= -1;
            m_EnableEventFiredThisInteract  = true;
            m_DisableEventFiredThisInteract = true;

            if (m_Animator != null) m_Animator.Rebind();

            if (m_FloatBlends != null) {
                for (int i = 0; i < m_FloatBlends.Length; ++i) {
                    m_FloatBlends[i].Active  = false;
                    m_FloatBlends[i].Elapsed = 0f;
                }
            }
			if (m_States != null) {
				for (int i = 0; i < m_States.Length; ++i) {
					StateManager.SetState(m_GameObject, m_States[i].Name, false);
				}
			}
            CancelFloatBlending();
        }

		/// <summary>Executes a named Opsive event on this GameObject.</summary>
        public void ExecuteEvent(string eventName) {
            Opsive.Shared.Events.EventHandler.ExecuteEvent(m_GameObject, eventName);
        }

		/// <summary>Looks up the cached state index and animator hash for a given state name.</summary>
		private bool TryGetCommandIndexAndHash(string command, out int index, out int hash) {
            hash  = 0;
            index = -1;

            if (m_CommandIndexLookup == null || !m_CommandIndexLookup.TryGetValue(command, out index))
                return false;
            if (m_CommandHashes == null || index < 0 || index >= m_CommandHashes.Length) {
                index = -1;
                return false;
            }
            hash = m_CommandHashes[index];
            return true;
        }
	#endregion

	#region Impact / FX Helpers
		/// <summary>Returns true if any enable actions are configured and valid.</summary>
        private bool HasEnableActions() {
			if (!m_EnableActionOverride.ActionEvent.WaitForAnimationEvent && m_EnableActionOverride.ActionEvent.Duration < 0) return false;

            return (m_EnableAction != null && m_EnableAction.Count > 0) ||
                   (m_EnableActionOverride != null && m_EnableActionOverride.ActionObject != null);
        }

		/// <summary>Returns true if any disable actions are configured and valid.</summary>
        private bool HasDisableActions() {
			if (!m_DisableActionOverride.ActionEvent.WaitForAnimationEvent && m_DisableActionOverride.ActionEvent.Duration < 0) return false;

            return (m_DisableAction != null && m_DisableAction.Count > 0) ||
                   (m_DisableActionOverride != null && m_DisableActionOverride.ActionObject != null);
        }

		/// <summary>Queues the enable ImpactActionGroup using its AnimationEventTrigger.</summary>
        private void RequestEnableAction() {
            if (!HasEnableActions()) return;

			m_EnableEventFiredThisInteract = false;
            m_EnableActionOverride.ActionEvent.WaitForEvent(true);
        }

		/// <summary>Queues the disable ImpactActionGroup using its AnimationEventTrigger.</summary>
        private void RequestDisableAction() {
            if (!HasDisableActions()) return;

			m_DisableEventFiredThisInteract = false;
            m_DisableActionOverride.ActionEvent.WaitForEvent(true);
        }

		/// <summary>Fires the enable ImpactActionGroup when its trigger condition is met.</summary>
        private void OnEnableActionEvent() {
            if (!m_EnableActionOverride.AllowLoopEvents && m_EnableEventFiredThisInteract) return;
            m_EnableEventFiredThisInteract = true;
            InvokeActionGroup(enableGroup: true);
			CompleteOneShotCommand();
        }

		/// <summary>Fires the disable ImpactActionGroup when its trigger condition is met.</summary>
        private void OnDisableActionEvent() {
            if (!m_DisableActionOverride.AllowLoopEvents && m_DisableEventFiredThisInteract) return;
			m_DisableEventFiredThisInteract = true;
            InvokeActionGroup(enableGroup: false);
			CompleteOneShotCommand();
        }

		/// <summary>Invokes the enable or disable ImpactActionGroup with a generated impact context.</summary>
        private void InvokeActionGroup(bool enableGroup) {
            var ctx           = BuildImpactContext();
            var overrideGroup = enableGroup ? m_EnableActionOverride.ActionObject : m_DisableActionOverride.ActionObject;
            var defaultGroup  = enableGroup ? m_EnableAction : m_DisableAction;

            if (overrideGroup != null) {
                overrideGroup.DoImpact(m_ImpactTarget.gameObject, null, ctx, forceImpact: true);
                return;
            }
            defaultGroup?.OnImpact(ctx, forceImpact: true);
        }

		/// <summary>Clears only the last remembered command/state after a one-shot command has completed.</summary>
		private void CompleteOneShotCommand() {
			if (!m_OneShotCommands) { return; }

			var index = m_LastInteractedCommandIndex;
			m_LastInteractedCommandIndex = -1;

			if (index < 0 || m_CommandParams == null || m_CommandHashes == null || index >= m_CommandParams.Length) {
				return;
			}

			var hash = m_CommandHashes[index];

			if (m_States != null) {
				for (int i = 0; i < m_States.Length; ++i) {
					if (m_States[i].Name == null) { continue; }

					if (m_CommandIndexLookup != null &&
						m_CommandIndexLookup.TryGetValue(m_States[i].Name, out var stateCommandIndex) &&
						stateCommandIndex == index) {
						StateManager.SetState(m_GameObject, m_States[i].Name, false);
						break;
					}
				}
			}

			if (m_Animator == null || hash == 0) { return; }
			switch (m_CommandParams[index]) {
				case Param.Bool:
					m_Animator.SetBool(hash, false);
					break;
				case Param.Int:
					m_Animator.SetInteger(hash, 0);
					break;
				case Param.Float:
					m_Animator.SetFloat(hash, 0f);
					break;
				case Param.Trigger:
					m_Animator.ResetTrigger(hash);
					break;
			}
		}

		/// <summary>Builds a reusable synthetic ImpactCallbackContext for action execution.</summary>
		private ImpactCallbackContext BuildImpactContext() {
            if (m_ImpactTarget == null)        m_ImpactTarget        = transform;
            if (m_CachedCollisionData == null) m_CachedCollisionData = new ImpactCollisionData();
            if (m_CachedCtx == null)           m_CachedCtx           = new ImpactCallbackContext();
            if (m_NoopDamageData == null)      m_NoopDamageData      = new ImpactDamageData();

            var data = m_CachedCollisionData;
            data.Reset();
            data.Initialize();

            data.SetImpactSource(m_GameObject, m_GameObject);
            data.SourceID = s_NextImpactSourceID++;

            if (m_TargetCollider != null) {
                data.SetImpactTarget(m_TargetCollider, m_ImpactTarget.gameObject);
            } else {
                data.ImpactGameObject = m_ImpactTarget.gameObject;
                var collider = m_ImpactTarget.GetComponent<Collider>();
                data.ImpactCollider  = collider;
                data.ImpactRigidbody = collider != null ? collider.attachedRigidbody : null;
            }

            var pos = m_ImpactTarget.position;
            var dir = pos - m_GameObject.transform.position;
            if (dir.sqrMagnitude < 0.0001f) {
                dir = m_GameObject.transform.forward.sqrMagnitude > 0.0001f
                    ? m_GameObject.transform.forward
                    : Vector3.up;
            }
            dir.Normalize();

            data.ImpactPosition  = pos;
            data.ImpactDirection = dir;
            data.ImpactStrength  = 1f;

            var hit = data.RaycastHit;
            hit.point  = pos;
            hit.normal = -dir;
            data.RaycastHit = hit;

            m_NoopDamageData.Reset();
            m_CachedCtx.ImpactCollisionData = data;
            m_CachedCtx.ImpactDamageData    = m_NoopDamageData;

            return m_CachedCtx;
        }
	#endregion

	#region Per-Parameter Implementations
		/// <summary>Triggers a one-shot animator trigger and queues enable/disable actions.</summary>
        private void HandleTriggerParam(int index, int hash) {
            if (m_Animator == null || hash == 0) {
                RequestEnableAction();
                return;
            }
            m_Animator.SetTrigger(hash);
            RequestEnableAction();
			RequestDisableAction();
        }

		/// <summary>Applies Int parameter logic based on the configured IntMode.</summary>
		private void HandleIntParam(int index, int hash) {
            var current = m_Animator.GetInteger(hash);
            var max     = m_TargetValue;

            switch (m_IntMode) {
                case IntMode.Absolute:
                    m_Animator.SetInteger(hash, max);
                    RequestEnableAction();
                    break;
                case IntMode.ResetCounter: {
                    var safeMax = Mathf.Max(0, max);
                    var next    = current + 1;
                    if (next > safeMax) next = 0;
                    m_Animator.SetInteger(hash, next);
                    RequestEnableAction();
                    break;
                }
                case IntMode.Counter:
                default: {
                    var safeMax = Mathf.Max(0, max);
                    var next    = current + 1;
                    if (next > safeMax) next = safeMax;
                    m_Animator.SetInteger(hash, next);
                    RequestEnableAction();
                    break;
                }
            }
        }

		/// <summary>Routes Bool parameter handling based on the configured BoolMode.</summary>
		private void HandleBoolParam(int index, int hash) {
            switch (m_BoolMode) {
                case BoolMode.Toggle:	HandleBool_Toggle(index, hash);	break;
                case BoolMode.Switch:	HandleBool_Switch(index, hash);	break;
                case BoolMode.Exclude:	HandleBool_Exclude(index, hash); break;
                default:				HandleBool_Toggle(index, hash);	break;
            }
        }

		/// <summary>Toggles a single Bool parameter on or off.</summary>
        private void HandleBool_Toggle(int index, int hash) {
            bool current = m_Animator.GetBool(hash);
            bool next    = !current;

            m_Animator.SetBool(hash, next);

            if (next) RequestEnableAction();
            else      RequestDisableAction();
        }

		/// <summary>Switches between “any on → all off” and “none on → this on” Bool behavior.</summary>
        private void HandleBool_Switch(int index, int hash) {
            bool anyTrue = false;

            for (int i = 0; i < m_CommandParams.Length; ++i) {
                if (m_CommandParams[i] != Param.Bool) continue;
                int h = m_CommandHashes[i];
                if (h == 0) continue;
                if (m_Animator.GetBool(h)) { anyTrue = true; break; }
            }

            if (anyTrue) { // Clear all bools.
                for (int i = 0; i < m_CommandParams.Length; ++i) {
                    if (m_CommandParams[i] != Param.Bool) continue;
                    int h = m_CommandHashes[i];
                    if (h == 0) continue;

                    if (!m_Animator.GetBool(h)) continue;

                    m_Animator.SetBool(h, false);
                }
                RequestDisableAction();
            } else { // No bools are true; set this one on.
                m_Animator.SetBool(hash, true);
                RequestEnableAction();
            }
        }

		/// <summary>Ensures this Bool is the only active Bool parameter.</summary>
        private void HandleBool_Exclude(int index, int hash) {
            // Turn all bools off.
            for (int i = 0; i < m_CommandParams.Length; ++i) {
                if (m_CommandParams[i] != Param.Bool) continue;
                int h = m_CommandHashes[i];
                if (h == 0) continue;

                if (!m_Animator.GetBool(h)) continue;

                m_Animator.SetBool(h, false);
            }

            // Turn THIS one on.
            m_Animator.SetBool(hash, true);
            RequestEnableAction();
        }

		/// <summary>Routes Float parameter handling based on the configured FloatMode.</summary>
		private void HandleFloatParam(int index, int hash) {
            var current   = m_Animator.GetFloat(hash);
            var turningOn = current <= 0.01f;

            switch (m_FloatMode) {
                case FloatMode.Additive:  HandleFloat_Additive(index, hash, current, turningOn);  break;
                case FloatMode.Invertive: HandleFloat_Invertive(index, hash, current, turningOn); break;
                case FloatMode.Exclusive: HandleFloat_Exclusive(index, hash, current, turningOn); break;
                default:                  HandleFloat_Additive(index, hash, current, turningOn);  break;
            }
        }

		/// <summary>Blends this Float on Excludely while blending others off.</summary>
        private void HandleFloat_Exclusive(int index, int hash, float current, bool turningOn) {
            if (turningOn) {
                // Blend all other float channels off.
                for (int i = 0; i < m_FloatBlends.Length; ++i) {
                    if (i == index || m_CommandParams[i] != Param.Float) continue;
                    int otherHash = m_CommandHashes[i];
                    if (otherHash == 0) continue;

                    float otherCurrent = m_Animator.GetFloat(otherHash);
                    if (otherCurrent > 0.01f)
                        StartFloatBlend(i, otherCurrent, 0f);
                }
                StartFloatBlend(index, current, 1f);
                RequestEnableAction();
            } else {
                StartFloatBlend(index, current, 0f);
                RequestDisableAction();
            }
        }

		/// <summary>Blends only this Float parameter on or off.</summary>
        private void HandleFloat_Additive(int index, int hash, float current, bool turningOn) {
            if (turningOn) {
                StartFloatBlend(index, current, 1f);
                RequestEnableAction();
            } else {
                StartFloatBlend(index, current, 0f);
                RequestDisableAction();
            }
        }

		/// <summary>Inverts this Float against all other Float parameters.</summary>
        private void HandleFloat_Invertive(int index, int hash, float current, bool turningOn) {
            if (turningOn) { // OFF -> ON: this to 1, others to 0.
                for (int i = 0; i < m_FloatBlends.Length; ++i) {
                    if (m_CommandParams[i] != Param.Float) continue;
                    int h = m_CommandHashes[i];
                    if (h == 0) continue;

                    float v = m_Animator.GetFloat(h);
                    if (i == index)      StartFloatBlend(i, v, 1f);
                    else if (v > 0.01f)  StartFloatBlend(i, v, 0f);
                }
                RequestEnableAction();
            } else { // ON -> OFF: this to 0, all others to 1.
                for (int i = 0; i < m_FloatBlends.Length; ++i) {
                    if (m_CommandParams[i] != Param.Float) continue;
                    int h = m_CommandHashes[i];
                    if (h == 0) continue;

                    float v = m_Animator.GetFloat(h);
                    if (i == index) StartFloatBlend(i, v, 0f);
                    else            StartFloatBlend(i, v, 1f);
                }
                RequestDisableAction();
            }
        }

		/// <summary>Starts or restarts a float blend for the given command index.</summary>
		private void StartFloatBlend(int index, float from, float to) {
            if (m_FloatBlends == null || index < 0 || index >= m_FloatBlends.Length) return;

            int hash = m_CommandHashes[index];
            if (hash == 0) return;

            ref var fb = ref m_FloatBlends[index];
            fb.From    = from;
            fb.To      = to;
            fb.Elapsed = 0f;
            fb.Active  = true;

            EnsureFloatBlendTick();
        }

		/// <summary>Schedules the float blend update tick if not already running.</summary>
        private void EnsureFloatBlendTick() {
            if (m_FloatBlendEvent != null) return;
            m_LastFloatBlendTime = Time.time;
            m_FloatBlendEvent    = Scheduler.Schedule(0f, FloatBlendTick);
        }

		/// <summary>Cancels the scheduled float blend update tick.</summary>
        private void CancelFloatBlending() {
            if (m_FloatBlendEvent == null) return;
            Scheduler.Cancel(m_FloatBlendEvent);
            m_FloatBlendEvent = null;
        }

		/// <summary>Updates active float blends and reschedules while blends remain active.</summary>
        private void FloatBlendTick() {
            m_FloatBlendEvent = null;
            if (m_Animator == null || m_FloatBlends == null || m_FloatBlends.Length == 0) return;

            var now = Time.time;
            var dt  = now - m_LastFloatBlendTime;
            if (dt <= 0f) dt = Time.deltaTime;
            m_LastFloatBlendTime = now;

            bool anyActive = false;
            var duration   = FloatBlendDuration;

            for (int i = 0; i < m_FloatBlends.Length; ++i) {
                ref var fb = ref m_FloatBlends[i];
                if (!fb.Active) continue;

                int hash = m_CommandHashes[i];
                if (hash == 0) { fb.Active = false; continue; }

                fb.Elapsed += dt;
                var t   = Mathf.Clamp01(fb.Elapsed / duration);
                var val = Mathf.Lerp(fb.From, fb.To, t);
                m_Animator.SetFloat(hash, val);

                if (t >= 1f) fb.Active = false;
                else         anyActive = true;
            }
            if (anyActive)
                m_FloatBlendEvent = Scheduler.Schedule(0f, FloatBlendTick);
        }
    #endregion
	}
}