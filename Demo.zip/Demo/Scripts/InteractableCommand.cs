﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
	using Opsive.UltimateCharacterController.Character.Abilities;
    using Opsive.UltimateCharacterController.Objects.CharacterAssist;
    using Opsive.UltimateCharacterController.Traits;
#if ULTIMATE_CHARACTER_CONTROLLER_MULTIPLAYER
    using Opsive.Shared.Game;
    using Opsive.UltimateCharacterController.Networking.Traits;
#endif
    using UnityEngine;

    /// <summary>
    /// Optional extension interface for targets that can receive a state name.
    /// </summary>
    public interface IInteractableCommandTarget : IInteractableTarget
    {
        void Interact(GameObject character, Interact interactAbility, string command);
    }

    /// <summary>
    /// Extends the Interactable script to send an optional state.
    /// </summary>
    public class InteractableCommand : Interactable
    {
        [Tooltip("The State that will be sent to each target.")]
        [SerializeField] protected string m_Command;

        private IInteractableTarget[] m_CachedTargets;
#if ULTIMATE_CHARACTER_CONTROLLER_MULTIPLAYER
        private INetworkInteractableMonitor m_NetworkInteractable;
#endif
        private bool m_Initialized;

        public string Command {
            get => m_Command;
            set => m_Command = value;
        }

        /// <summary>
        /// Ensures the local runtime caches are initialized.
        /// </summary>
        protected virtual void Initialize()
        {
            if (m_Initialized) {
                return;
            }

            var targets = Targets;
            if (targets == null || targets.Length == 0) {
                Debug.LogError("Error: An IInteractableTarget must be specified in the Targets field.", this);
                m_CachedTargets = System.Array.Empty<IInteractableTarget>();
                m_Initialized = true;
                return;
            }

            m_CachedTargets = new IInteractableTarget[targets.Length];

            for (int i = 0; i < targets.Length; ++i) {
                if (targets[i] == null || !(targets[i] is IInteractableTarget interactableTarget)) {
                    Debug.LogError($"Error: Element {i} of the Targets array is null or does not implement IInteractableTarget.", this);
                    continue;
                }

                m_CachedTargets[i] = interactableTarget;
            }

#if ULTIMATE_CHARACTER_CONTROLLER_MULTIPLAYER
            m_NetworkInteractable = gameObject.GetCachedComponent<INetworkInteractableMonitor>();
#endif

            m_Initialized = true;
        }

        /// <summary>
        /// Performs the interaction.
        /// </summary>
        /// <param name="character">The character that wants to interact with the target.</param>
        /// <param name="interactAbility">The ability that triggers the interaction.</param>
        public override void Interact(GameObject character, Interact interactAbility)
        {
            Initialize();

#if ULTIMATE_CHARACTER_CONTROLLER_MULTIPLAYER
            var characterNetworkInfo = character.GetCachedComponent<Shared.Networking.INetworkInfo>();
            if (characterNetworkInfo != null && characterNetworkInfo.HasAuthority()) {
#if UNITY_EDITOR
                if (m_NetworkInteractable == null) {
                    Debug.LogError($"Error: The object {gameObject.name} must have a NetworkInteractable component.");
                }
#endif
                m_NetworkInteractable?.Interact(character, interactAbility);
            }
#endif

            for (int i = 0; i < m_CachedTargets.Length; ++i) {
                var target = m_CachedTargets[i];
                if (target == null) {
                    continue;
                }

                if (target is IInteractableCommandTarget commandTarget) {
                    commandTarget.Interact(character, interactAbility, m_Command);
                } else {
                    target.Interact(character, interactAbility);
                }
            }
        }
    }
}