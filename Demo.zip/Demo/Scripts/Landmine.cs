﻿namespace Opsive.UltimateCharacterController.AddOns.Challenge.Demo
{
	using Opsive.Shared.Audio;
	using Opsive.Shared.Game;
	using UnityEngine;

    /// <summary>
    /// Executes an event when a valid target enters the trigger.
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class Landmine : MonoBehaviour
    {
        [Tooltip("Layers that can trigger the mine.")]
        [SerializeField] protected LayerMask m_TargetLayers = ~0;

        [Tooltip("Should the mine only trigger once?")]
        [SerializeField] protected bool m_TriggerOnce = true;

		[Tooltip("The amount of time to delay the trigger.")]
		[SerializeField] protected float m_TriggerDelay = 0.5f;

		[Tooltip("The audio that plays while the landmine is armed")]
		[SerializeField] protected AudioClipSet m_ArmedAudio;

		[Tooltip("The audio that plays on trigger.")]
		[SerializeField] protected AudioClipSet m_TriggerAudio;

        [Tooltip("Invoked when a valid target enters the trigger.")]
        [SerializeField] protected UnityEngine.Events.UnityEvent<Collider> m_OnTriggered;

        private bool m_Triggered;

        /// <summary>
        /// Initialize the trigger collider.
        /// </summary>
        protected virtual void Awake()
        {
            var collider = GetComponent<Collider>();

            if (collider == null) {
                Debug.LogError($"Error: A Collider is required on {name}.", this);
                return;
            }

            if (!collider.isTrigger) {
                collider.isTrigger = true;
            }
        }

        /// <summary>
        /// A collider entered the trigger.
        /// </summary>
        /// <param name="other">The collider that entered.</param>
        protected virtual void OnTriggerEnter(Collider other)
		{
			if (m_Triggered && m_TriggerOnce) {
				return;
			}

			if ((m_TargetLayers.value & (1 << other.gameObject.layer)) == 0) {
				return;
			}

			m_Triggered = true;
			m_ArmedAudio?.Stop(gameObject);
			m_TriggerAudio?.PlayAudioClip(gameObject);
			Scheduler.Schedule(m_TriggerDelay, () => m_OnTriggered?.Invoke(other));
		}

        /// <summary>
        /// Resets the trigger state.
        /// </summary>
        public virtual void OnEnable()
        {
			m_ArmedAudio?.PlayAudioClip(gameObject, true);
			m_Triggered = false;
        }
    }
}